
import time
import cv2
try:
    from twilio.rest import Client
except Exception:
    Client = None

# Minimal face detection + SMS alert stub.
# - Uses Haar cascades for light demo (no training required).
# - Sends SMS via Twilio if credentials are present; otherwise logs to console.

def send_sms(body: str):
    account_sid = "TWILIO_ACCOUNT_SID"
    auth_token = "TWILIO_AUTH_TOKEN"
    to_number = "+911234567890"
    from_number = "+15005550006"  # Twilio test number

    if Client is None or "TWILIO" in account_sid:
        print(f"[DEBUG] SMS -> {to_number}: {body}")
        return

    client = Client(account_sid, auth_token)
    client.messages.create(body=body, from_=from_number, to=to_number)

def run_demo():
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open webcam. Exiting demo.")
        return

    last_alert = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(80, 80))

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        if len(faces) > 0 and time.time() - last_alert > 10:
            send_sms("Safeguard Alert: Face detected.")
            last_alert = time.time()

        cv2.putText(frame, "Safeguard Demo - Press 'q' to quit", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
        cv2.imshow("Safeguard", frame)
        if cv2.waitKey(1) & 0.FF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_demo()
